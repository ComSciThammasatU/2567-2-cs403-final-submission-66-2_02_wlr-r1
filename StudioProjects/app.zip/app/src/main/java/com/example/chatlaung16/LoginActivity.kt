package com.example.chatlaung16
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*

 class LoginActivity : AppCompatActivity() {

    private lateinit var etHomeNumber: EditText
    private lateinit var etDayin: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etHomeNumber = findViewById(R.id.editHouseNumber)
        etDayin = findViewById(R.id.editDate)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val homeId = etHomeNumber.text.toString()
            val dayin = etDayin.text.toString()
            if (homeId == "8800" && dayin == "000022") {
                Toast.makeText(this, "เข้าสู่ระบบผู้ดูแล", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, AdminActivity::class.java))
                return@setOnClickListener
            }
            val idInt = homeId.toIntOrNull()
            val expectedPassword = idInt?.let { generatePasswordFromId(it) }

            if (expectedPassword == null) {
                Toast.makeText(this, "ID ไม่ถูกต้องหรือเกินช่วง", Toast.LENGTH_SHORT).show()
            } else if (dayin == expectedPassword) {
                Toast.makeText(this, "เข้าสู่ระบบสำเร็จ", Toast.LENGTH_SHORT).show()
                // TODO: เปลี่ยนหน้าไป MainActivity หรืออื่น ๆ ตรงนี้
                startActivity(Intent(this, HomeActivity::class.java))
            } else {
                Toast.makeText(this, "รหัสผ่านไม่ถูกต้อง", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generatePasswordFromId(id: Int): String? {
        val baseId = 8801
        val offset = id - baseId

        if (offset < 0 || id > 88168) return null // จำกัดสูงสุดที่ 88168 ตามเงื่อนไข

        val calendar = Calendar.getInstance().apply {
            set(2022, 0, 1) // เริ่มที่ 1 ม.ค. 2022
            add(Calendar.DAY_OF_YEAR, offset)
        }

        val day = calendar.get(Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
        val month = (calendar.get(Calendar.MONTH) + 1).toString().padStart(2, '0')
        val year = "22" // ปีคงที่

        return "$day$month$year"
    }
}