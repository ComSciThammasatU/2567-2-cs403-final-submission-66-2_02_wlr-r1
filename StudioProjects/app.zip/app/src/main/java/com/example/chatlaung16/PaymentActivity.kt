package com.example.chatlaung16

import android.util.Base64
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Response
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import com.android.volley.toolbox.StringRequest
class PaymentActivity : AppCompatActivity() {

    private lateinit var etHouseNumber: EditText
    private lateinit var etPaymentTime: EditText
    private lateinit var btnUploadImage: Button
    private lateinit var btnSend: Button
    private var imageUri: Uri? = null

    private val PICK_IMAGE_REQUEST = 1
    private val scriptUrl = "https://script.google.com/macros/s/AKfycbxPj0s_1cEmnVPclzLuyOyunFt5S80JcHkQ2XuADykX_YlEnKVvSILolnMfonILkuY/exec"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        etHouseNumber = findViewById(R.id.etHouseNumber)
        etPaymentTime = findViewById(R.id.etPaymentTime)
        btnUploadImage = findViewById(R.id.btnUpload)
        btnSend = findViewById(R.id.btnSend)

        btnUploadImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "image/*"
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        btnSend.setOnClickListener {
            val houseNumber = etHouseNumber.text.toString().trim()
            val paymentTime = etPaymentTime.text.toString().trim()

            if (houseNumber.isEmpty() || paymentTime.isEmpty()) {
                Toast.makeText(this, "กรุณากรอกข้อมูลให้ครบ", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val base64Image = imageUri?.let { convertImageToBase64(it) }

            sendDataToSheet(houseNumber, paymentTime, base64Image)
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            imageUri = data.data
            Toast.makeText(this, "เลือกรูปภาพแล้ว", Toast.LENGTH_SHORT).show()
        }
    }

    private fun convertImageToBase64(uri: Uri): String? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val bytes = inputStream?.readBytes()
            inputStream?.close()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun sendDataToSheet(houseNumber: String, paymentTime: String, base64Image: String?) {
        val jsonBody = JSONObject().apply {
            put("houseNumber", houseNumber)
            put("paymentTime", paymentTime)
            put("imageBase64", base64Image ?: "")
        }

        val request = object : StringRequest(
            Method.POST, scriptUrl,
            Response.Listener { response ->
                Toast.makeText(this, "ส่งข้อมูลสำเร็จ", Toast.LENGTH_SHORT).show()
            },
            Response.ErrorListener { error ->
                Toast.makeText(this, "ส่งข้อมูลไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                error.printStackTrace()
            }
        ) {
            override fun getBodyContentType() = "application/json; charset=utf-8"
            override fun getBody() = jsonBody.toString().toByteArray(Charsets.UTF_8)
        }

        Volley.newRequestQueue(this).add(request)
    }

}
